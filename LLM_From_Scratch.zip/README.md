# LLM-from-scratch-workshop

Code associated with LLM from scratch workshop presented at Rajalakshmi Engineering College , Chennai


## Code Credits:

The notebooks used in the workshop are taken from this wonderful [repository](https://github.com/rasbt/LLMs-from-scratch) by Sebastian Raschka. I would highly recommend to follow the other exercises in the repo and book as a follow up.
